package com.example.studentgigs.data.repository

import android.content.Context
import android.util.Log
import com.example.studentgigs.data.model.*
import com.example.studentgigs.data.remote.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

sealed class ApplicationResult {
    data class Success(
        val applied: Boolean = false,
        val applications: List<Application> = emptyList(),
        val appliedTaskIds: Set<Long> = emptySet()
    ) : ApplicationResult()
    data class Error(val message: String) : ApplicationResult()
}

class ApplicationRepository(context: Context) {

    private val apiClient = ApiClient()

    companion object {
        private const val TAG = "ApplicationRepository"

        @Volatile
        private var INSTANCE: ApplicationRepository? = null

        fun getInstance(context: Context): ApplicationRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ApplicationRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /** Откликнуться на задание */
    suspend fun applyToTask(studentId: Long, taskId: Long): ApplicationResult =
        withContext(Dispatchers.IO) {
            try {
                val response = apiClient.applyToTask(studentId, taskId)
                val json = JSONObject(response.body)

                if (json.optBoolean("success", false)) {
                    val data = json.optJSONObject("data")
                    val applied = data?.optBoolean("applied", false) ?: false
                    ApplicationResult.Success(applied = applied)
                } else {
                    ApplicationResult.Error(json.optString("message", "Ошибка отклика"))
                }
            } catch (e: Exception) {
                Log.e(TAG, "applyToTask error", e)
                ApplicationResult.Error(e.message ?: "Неизвестная ошибка")
            }
        }

    /** Получить все отклики студента */
    suspend fun getApplications(studentId: Long): ApplicationResult =
        withContext(Dispatchers.IO) {
            try {
                val response = apiClient.getApplications(studentId)
                val json = JSONObject(response.body)

                if (!json.optBoolean("success", false)) {
                    return@withContext ApplicationResult.Error(
                        json.optString("message", "Ошибка загрузки откликов")
                    )
                }

                val data = json.optJSONObject("data") ?: return@withContext ApplicationResult.Error("Нет данных")
                val appsArray = data.optJSONArray("applications") ?: JSONArray()
                val appliedIdsArray = data.optJSONArray("applied_task_ids") ?: JSONArray()

                val applications = mutableListOf<Application>()
                for (i in 0 until appsArray.length()) {
                    val obj = appsArray.getJSONObject(i)
                    val taskObj = obj.optJSONObject("task")
                    val task = taskObj?.let { parseTask(it) }
                    val statusStr = obj.optString("application_status", "PENDING")
                    val status = try {
                        ApplicationStatus.valueOf(statusStr)
                    } catch (e: IllegalArgumentException) {
                        ApplicationStatus.PENDING
                    }
                    applications.add(
                        Application(
                            applicationId = obj.optLong("application_id"),
                            studentId = obj.optLong("student_id"),
                            taskId = obj.optLong("task_id"),
                            status = status,
                            appliedAt = obj.optLong("applied_at"),
                            task = task
                        )
                    )
                }

                val appliedTaskIds = mutableSetOf<Long>()
                for (i in 0 until appliedIdsArray.length()) {
                    appliedTaskIds.add(appliedIdsArray.getLong(i))
                }

                ApplicationResult.Success(
                    applications = applications,
                    appliedTaskIds = appliedTaskIds
                )
            } catch (e: Exception) {
                Log.e(TAG, "getApplications error", e)
                ApplicationResult.Error(e.message ?: "Неизвестная ошибка")
            }
        }

    // ────────────────────────────────────────────────
    // Парсинг Task из JSON
    // ────────────────────────────────────────────────

    private fun parseTask(json: JSONObject): Task {
        val type = try { TaskType.valueOf(json.optString("type", "TASK")) } catch (e: Exception) { TaskType.TASK }
        val priceType = try { PriceType.valueOf(json.optString("price_type", "FIXED")) } catch (e: Exception) { PriceType.FIXED }
        val locationType = try { LocationType.valueOf(json.optString("location_type", "REMOTE")) } catch (e: Exception) { LocationType.REMOTE }
        val status = try { TaskStatus.valueOf(json.optString("status", "ACTIVE")) } catch (e: Exception) { TaskStatus.ACTIVE }
        val empType = json.optString("employment_type", "").takeIf { it.isNotBlank() }?.let {
            try { EmploymentType.valueOf(it) } catch (e: Exception) { null }
        }

        fun splitPipe(str: String?) = str?.split("|")?.filter { it.isNotBlank() } ?: emptyList()

        return Task(
            id = json.optLong("id"),
            employerId = json.optLong("employer_id"),
            employerName = json.optString("employer_name", ""),
            employerPosition = json.optString("employer_position", "").takeIf { it.isNotBlank() },
            type = type,
            title = json.optString("title", ""),
            description = json.optString("description", ""),
            requirements = splitPipe(json.optString("requirements", "")),
            benefits = splitPipe(json.optString("benefits", "")),
            tags = splitPipe(json.optString("tags", "")),
            price = json.optString("price", ""),
            priceType = priceType,
            duration = json.optString("duration", ""),
            location = json.optString("location", ""),
            locationType = locationType,
            deadline = json.optLong("deadline").takeIf { it != 0L },
            status = status,
            createdAt = json.optLong("created_at"),
            responsesCount = json.optInt("responses_count"),
            iconEmoji = json.optString("icon_emoji", "📋"),
            employmentType = empType,
            schedule = json.optString("schedule", "").takeIf { it.isNotBlank() },
            serviceCategory = json.optString("service_category", "").takeIf { it.isNotBlank() }
        )
    }
}
