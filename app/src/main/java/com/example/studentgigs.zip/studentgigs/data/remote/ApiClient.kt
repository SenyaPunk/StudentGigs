package com.example.studentgigs.data.remote

import com.example.studentgigs.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

// HTTP клиент для работы с API на сервере
class ApiClient {

    // Регистрация
    suspend fun register(
        email: String,
        password: String,
        role: String,
        fullName: String? = null,
        companyName: String? = null,
        companyPosition: String? = null
    ): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("email", email)
            put("password", password)
            put("role", role)
            fullName?.let { put("full_name", it) }
            companyName?.let { put("company_name", it) }
            companyPosition?.let { put("company_position", it) }
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.REGISTER, json.toString())
    }

    // Вход
    suspend fun login(email: String, password: String): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("email", email)
            put("password", password)
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.LOGIN, json.toString())
    }

    // Получение данных по айди
    suspend fun getUser(userId: Long): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply { put("user_id", userId) }
        postRequest(ApiConfig.BASE_URL + ApiConfig.GET_USER, json.toString())
    }

    // Обновление данных
    suspend fun updateUser(
        userId: Long,
        fullName: String? = null,
        companyName: String? = null,
        companyPosition: String? = null
    ): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("user_id", userId)
            fullName?.let { put("full_name", it) }
            companyName?.let { put("company_name", it) }
            companyPosition?.let { put("company_position", it) }
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.UPDATE_USER, json.toString())
    }

    // Верификация работодателя
    suspend fun verifyEmployer(userId: Long, passportPhotoUrl: String): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("user_id", userId)
            put("passport_photo_url", passportPhotoUrl)
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.VERIFY_EMPLOYER, json.toString())
    }

    // Проверка статуса верификации
    suspend fun checkVerification(userId: Long): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply { put("user_id", userId) }
        postRequest(ApiConfig.BASE_URL + ApiConfig.CHECK_VERIFICATION, json.toString())
    }

    // Создание задания
    suspend fun createTask(
        employerId: Long,
        type: TaskType,
        title: String,
        description: String,
        price: String,
        requirements: List<String> = emptyList(),
        benefits: List<String> = emptyList(),
        tags: List<String> = emptyList(),
        priceType: PriceType = PriceType.FIXED,
        duration: String = "",
        location: String = "",
        locationType: LocationType = LocationType.REMOTE,
        deadline: Long? = null,
        iconEmoji: String = "📋",
        employmentType: EmploymentType? = null,
        schedule: String? = null,
        serviceCategory: String? = null
    ): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("employer_id", employerId)
            put("type", type.name)
            put("title", title)
            put("description", description)
            put("price", price)
            put("requirements", requirements.joinToString("|"))
            put("benefits", benefits.joinToString("|"))
            put("tags", tags.joinToString("|"))
            put("price_type", priceType.name)
            put("duration", duration)
            put("location", location)
            put("location_type", locationType.name)
            deadline?.let { put("deadline", it) }
            put("icon_emoji", iconEmoji)
            employmentType?.let { put("employment_type", it.name) }
            schedule?.let { put("schedule", it) }
            serviceCategory?.let { put("service_category", it) }
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.CREATE_TASK, json.toString())
    }

    // Получение заданий
    suspend fun getTasks(
        type: String? = null,
        employerId: Long? = null,
        status: String = "ACTIVE",
        limit: Int = 50,
        offset: Int = 0
    ): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            type?.let { put("type", it) }
            employerId?.let { put("employer_id", it) }
            put("status", status)
            put("limit", limit)
            put("offset", offset)
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.GET_TASKS, json.toString())
    }

    // ─────────────────────────────────────────────
    // ОТКЛИКИ
    // ─────────────────────────────────────────────

    /**
     * Откликнуться на задание.
     * Если отклик уже существует — сервер вернёт applied=true без ошибки.
     */
    suspend fun applyToTask(studentId: Long, taskId: Long): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("student_id", studentId)
            put("task_id", taskId)
        }
        postRequest(ApiConfig.BASE_URL + ApiConfig.APPLY_TASK, json.toString())
    }

    /**
     * Получить все отклики студента.
     * Возвращает список Application с вложенным Task.
     */
    suspend fun getApplications(studentId: Long): ApiResponse = withContext(Dispatchers.IO) {
        val json = JSONObject().apply { put("student_id", studentId) }
        postRequest(ApiConfig.BASE_URL + ApiConfig.GET_APPLICATIONS, json.toString())
    }

    // ─────────────────────────────────────────────
    // HTTP
    // ─────────────────────────────────────────────

    private fun postRequest(url: String, jsonBody: String): ApiResponse {
        return try {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                doOutput = true
                connectTimeout = 15_000
                readTimeout = 15_000
            }
            OutputStreamWriter(connection.outputStream, "UTF-8").use { it.write(jsonBody) }

            val responseCode = connection.responseCode
            val responseBody = if (responseCode in 200..299) {
                BufferedReader(InputStreamReader(connection.inputStream, "UTF-8"))
                    .use { it.readText() }
            } else {
                BufferedReader(InputStreamReader(connection.errorStream ?: connection.inputStream, "UTF-8"))
                    .use { it.readText() }
            }
            ApiResponse(responseCode, responseBody)
        } catch (e: Exception) {
            ApiResponse(-1, """{"success":false,"message":"${e.message}"}""")
        }
    }
}