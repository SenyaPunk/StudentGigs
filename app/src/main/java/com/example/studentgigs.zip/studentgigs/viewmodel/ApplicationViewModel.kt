package com.example.studentgigs.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.studentgigs.data.model.ApplicationStatus
import com.example.studentgigs.data.repository.ApplicationRepository
import com.example.studentgigs.data.repository.ApplicationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ApplicationUiState(
    val isLoading: Boolean = false,
    val applications: List<Application> = emptyList(),
    // Множество task_id, на которые студент уже откликнулся
    val appliedTaskIds: Set<Long> = emptySet(),
    val error: String? = null,
    // ID задания, которое прямо сейчас отправляется (для показа прогресс-индикатора)
    val applyingTaskId: Long? = null
)

class ApplicationViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ApplicationRepository.getInstance(application)

    private val _uiState = MutableStateFlow(ApplicationUiState())
    val uiState: StateFlow<ApplicationUiState> = _uiState.asStateFlow()

    // ─────────────────────────────────────────
    // Загрузка откликов
    // ─────────────────────────────────────────

    fun loadApplications(studentId: Long) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)

            when (val result = repository.getApplications(studentId)) {
                is ApplicationResult.Success -> _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    applications = result.applications,
                    appliedTaskIds = result.appliedTaskIds
                )
                is ApplicationResult.Error -> _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = result.message
                )
            }
        }
    }

    // ─────────────────────────────────────────
    // Отклик на задание
    // ─────────────────────────────────────────

    fun applyToTask(studentId: Long, taskId: Long) {
        // Не отправляем повторный запрос если уже откликнулись
        if (_uiState.value.appliedTaskIds.contains(taskId)) return
        // Не отправляем если уже идёт запрос
        if (_uiState.value.applyingTaskId != null) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(applyingTaskId = taskId, error = null)

            when (val result = repository.applyToTask(studentId, taskId)) {
                is ApplicationResult.Success -> {
                    // Оптимистично добавляем task_id в список откликов
                    val newAppliedIds = _uiState.value.appliedTaskIds + taskId
                    _uiState.value = _uiState.value.copy(
                        applyingTaskId = null,
                        appliedTaskIds = newAppliedIds
                    )
                    // Обновляем полный список откликов с сервера
                    loadApplications(studentId)
                }
                is ApplicationResult.Error -> _uiState.value = _uiState.value.copy(
                    applyingTaskId = null,
                    error = result.message
                )
            }
        }
    }

    // ─────────────────────────────────────────
    // Вспомогательные методы
    // ─────────────────────────────────────────

    fun isApplied(taskId: Long): Boolean =
        _uiState.value.appliedTaskIds.contains(taskId)

    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }

    // Группировка для экрана "Мои проекты"
    val pendingApplications: List<Application>
        get() = _uiState.value.applications.filter { it.status == ApplicationStatus.PENDING }

    val inProgressApplications: List<Application>
        get() = _uiState.value.applications.filter { it.status == ApplicationStatus.IN_PROGRESS }

    val completedApplications: List<Application>
        get() = _uiState.value.applications.filter { it.status == ApplicationStatus.COMPLETED }
}
