package com.example.studentgigs.data.model

enum class ApplicationStatus {
    PENDING,      // Вы откликнулись (ожидает решения работодателя)
    IN_PROGRESS,  // В работе (работодатель принял)
    COMPLETED,    // Завершено
    REJECTED      // Отклонено
}

data class Application(
    val applicationId: Long = 0,
    val studentId: Long,
    val taskId: Long,
    val status: ApplicationStatus = ApplicationStatus.PENDING,
    val appliedAt: Long = System.currentTimeMillis(),
    val task: Task? = null
)
